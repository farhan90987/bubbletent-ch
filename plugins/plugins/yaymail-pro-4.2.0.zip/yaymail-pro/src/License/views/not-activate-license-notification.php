<div class="update-message notice inline notice-warning notice-alt">
    <p>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=yaycommerce-licenses' ) ); ?>"><?php esc_html_e( 'Please activate your license for access to premium features and automatic updates', 'yaymail' ); ?></a>.
    </p>
</div>

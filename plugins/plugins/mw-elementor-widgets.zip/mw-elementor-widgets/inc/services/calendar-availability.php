<?php 

namespace MWEW\Inc\Services;
use DateTime;
use MWEW\Inc\Logger\Logger;

class Calendar_Availability{

    public static function get_busy_days_by_id($property_id){
        global $wpdb;
        
        $results = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT open_dates 
                FROM {$wpdb->prefix}smoobu_calendar_availability 
                WHERE property_id = %d",
                $property_id
            )
        );

        return $results;

    }


    private static function get_date_range($start_date, $end_date) {
        $dates = [];
        $current = strtotime($start_date);
        $end = strtotime($end_date);

        while ($current <= $end) {
            $dates[] = date('Y-m-d', $current);
            $current = strtotime('+1 day', $current);
        }

        return $dates;
    }

    public static function is_available($listing_id, $check_in, $check_out){

        $checkin_date = isset($check_in) ? sanitize_text_field($check_in) : '';
        $checkout_date = isset($check_out) ? sanitize_text_field($check_out) : '';

        if (!self::validate_date($checkin_date) || !self::validate_date($checkout_date)) {
            //Logger::debug("check ing $checkin_date checkout: $checkout_date");
            return false;
        }

        $woocommerce_id = get_post_meta($listing_id, 'product_id', true);

        $property_id = wc_get_product($woocommerce_id)->get_meta('custom_property_id_field');
        
        $opend_data = self::get_busy_days_by_id(($property_id));

        $next_available_dates = json_decode( $opend_data, true);

        $date_range = self::get_date_range($checkin_date, $checkout_date);
        
        
        $all_available = true;
        foreach ($date_range as $date) {
            if (!isset($next_available_dates[$date])) {
                $all_available = false;
                break;
            }
        }

       // Logger::debug("is_available: Listing ID: " . get_the_ID() . " Check in " . $checkin_date . " Check out " . $checkout_date . ' Status ' . $all_available);


        return $all_available;
    }

    public static function validate_date($date) {
        $formats = [
            'd-m-Y',
            'd.m.Y',
            'Y-m-d',
            'Y.m.d',
            'm-d-Y',
            'm.d.Y'
        ];


        foreach ($formats as $format) {
            $d = DateTime::createFromFormat($format, $date);
            if ($d && $d->format($format) === $date) {
                return true;
            }
        }

        return false;
    }


}
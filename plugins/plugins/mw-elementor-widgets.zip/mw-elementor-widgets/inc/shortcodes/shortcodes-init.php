<?php 
namespace MWEW\Inc\Shortcodes;

class Shortcodes_Init{
    public function __construct(){
        new MW_Search_Form_Shortcode();
        new MW_Search_Action();
    }
}
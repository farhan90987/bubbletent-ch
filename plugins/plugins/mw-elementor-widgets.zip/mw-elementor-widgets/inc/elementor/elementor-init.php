<?php
namespace MWEW\Inc\Elementor;

use MWEW\Inc\Elementor\Widgets\Area_Map\Country_Map;
use MWEW\Inc\Elementor\Widgets\Loop_Carousel\Template_Loop_Carousel;
use MWEW\Inc\Elementor\Widgets\Hero_Slider\MW_Hero_Slider;

class Elementor_Init{
    public function __construct(){
        
        add_action( 'elementor/widgets/register', [$this, 'register_widget'] );
    }

    public function register_widget( $widgets_manager ) {
        $widgets_manager->register( new Template_Loop_Carousel() );
        $widgets_manager->register( new Country_Map() );
        $widgets_manager->register( new MW_Hero_Slider() );
    }
}






<?php

namespace MWEW\Inc\Elementor\Widgets\Hero_Slider;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

class MW_Hero_Slider extends Widget_Base
{
	public function get_name(): string {
		return 'book_hero_bg_slider';
	}

	public function get_title(): string {
		return esc_html__('Hero Background Slider', 'listeo');
	}

	public function get_icon(): string {
		return 'eicon-background';
	}

	public function get_categories(): array {
		return ['basic'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_images',
			[
				'label' => __('Background Images', 'listeo'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => __('Desktop Image', 'listeo'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'mobile_image',
			[
					'label' => __('Mobile Image', 'listeo'),
					'type' => Controls_Manager::MEDIA,
					'default' => [
							'url' => Utils::get_placeholder_image_src(),
					],
			]
	);

		$this->add_control(
			'slides',
			[
				'label' => __('Slides', 'listeo'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [],
				'title_field' => 'Slider Image',
			]
		);

		$this->add_control(
			'left_content',
			[
				'label' => __('Left Content', 'listeo'),
				'type' => Controls_Manager::WYSIWYG,
				'default' => __('This is some content for the left side.', 'listeo'),
				'placeholder' => __('Enter content here', 'listeo'),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_left_style',
			[
				'label' => __('Left Content Style', 'listeo'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'left_text_color',
			[
				'label' => __('Text Color', 'listeo'),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .slider-left' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'left_typography',
				'label' => __('Typography', 'listeo'),
				'selector' => '{{WRAPPER}} .slider-left',
			]
		);

		$this->add_responsive_control(
			'left_text_align',
			[
				'label' => __('Text Alignment', 'listeo'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => ['title' => __('Left'), 'icon' => 'eicon-text-align-left'],
					'center' => ['title' => __('Center'), 'icon' => 'eicon-text-align-center'],
					'right' => ['title' => __('Right'), 'icon' => 'eicon-text-align-right'],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .slider-left' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'left_padding',
			[
				'label' => __('Padding'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .slider-left' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_mobile_buttons',
			[
				'label' => __('Mobile Buttons', 'mwew'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'button_icon',
			[
				'label' => __('Button Icon', 'plugin-name'),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => '',
					'library' => 'solid',
				],
			]
		);


		$repeater->add_control(
			'button_text',
			[
				'label' => __('Button Text', 'mwew'),
				'type' => Controls_Manager::TEXT,
				'default' => __('Click Me', 'mwew'),
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label' => __('Button Link', 'mwew'),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '#0',
					'is_external' => false,
					'nofollow' => false,
				],
			]
		);

		$this->add_control(
			'mobile_buttons',
			[
				'label' => __('Buttons', 'mwew'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'button_text' => __('Standorte entdecken', 'mwew'),
						'button_link' => ['url' => '#0']
					],
					[
						'button_text' => __('Gutschein bestellen', 'mwew'),
						'button_link' => ['url' => '#0']
					]
				],
			]
		);

		$this->end_controls_section();
	}

	public function get_style_depends() {
	    return ['mw-hero-slider'];
	}

	public function get_script_depends() {
	    return ['mw-hero-slider'];
	}

	protected function render(): void {
		$settings = $this->get_settings_for_display();
		if (empty($settings['slides'])) return;

		$image_urls = array_map(fn($slide) => esc_url($slide['image']['url']), $settings['slides']);
		$mobile_image_urls = array_map(fn($slide) => esc_url($slide['mobile_image']['url']), $settings['slides']);
		$data_src = htmlspecialchars(json_encode($image_urls), ENT_QUOTES, 'UTF-8');
		$mobile_data_src = htmlspecialchars(json_encode($mobile_image_urls), ENT_QUOTES, 'UTF-8');
		

		$first_image = $settings['slides'][0]['image']['url'];

		$unique_id = 'hero-bg-slider-' . $this->get_id();

		// Child theme asset URLs
		$theme_uri = get_stylesheet_directory_uri();
		$calendar_icon = esc_url($theme_uri . '/elementor/assets/calendar.png');
		$search_icon = esc_url($theme_uri . '/elementor/assets/search_icon.png');

		echo '<div id="' . esc_attr($unique_id) . '" class="book-hero-bg-slider" style="background-image:url("'. $first_image .'")" data-src="' . $data_src . '" data-mobile-src="'. $mobile_data_src .'">
			<div class="slider-inner">
				<div class="slider-left">
					<div class="left-inner">
						<span class="uppercase">'.__("Entdecke die außergewöhnliche", "listeo").'</span>
						<span class="uppercase">'.__("Seite der", "listeo").' <span class="font-aclonica-logo">'.__("Schweiz", "listeo").' <img decoding="async" src="https://book-a-bubble.ch/wp-content/uploads/2025/05/switzerland-1.png" alt="switzerland"></span></span>
						<span>'.__("mit", "listeo").' <span class="font-aclonica-logo">'.__("Book a Bubble", "listeo").'</span></span>

						<span class="small-info">'.__("Romantisch einzigartig", "listeo").'</span>
					</div>
					<div class="slider-dots"></div>
				</div>
				<div class="slider-right">
					<div class="search-container">
						<div class="search-row">
							<div class="search-field">
								<span class="label">'. esc_html__("Check-in Datum", "listeo") .'</span>
								<div class="input-wrapper" id="checkin-wrapper">
									<input type="text" class="date-input checkin-date" id="mwew-checkin-date" placeholder="'.__("Anreise", "listeo").'" readonly>
									<img src="/wp-content/uploads/2025/05/Calendar.png" alt="calendar icon" class="icon">
								</div>
							</div>
							<div class="search-field">
								<span class="label">'. esc_html__("Check-out Datum", "listeo") .'</span>
								<div class="input-wrapper" id="checkout-wrapper">
									<input type="text" class="date-input checkout-date" id="mwew-checkout-date" placeholder="'.__("Abreise", "listeo").'" readonly>
									<img src="/wp-content/uploads/2025/05/Calendar.png" alt="calendar icon" class="icon">
								</div>
							</div>
						</div>
						<div class="search-button" data-home-url="' . esc_url( home_url() ) . '">
							<img src="/wp-content/uploads/2025/05/Search.png" alt="search icon" class="icon">
							<span>'. esc_html__("Verfügbare Bubble Tents anzeigen", "listeo") .'</span>
						</div>
					</div>
				</div>
			</div>';

			echo '<div class="mobile-btn">';
				if ( ! empty( $settings['mobile_buttons'] ) ) {
					foreach ( $settings['mobile_buttons'] as $button ) {
						$link = ! empty( $button['button_link']['url'] ) ? $button['button_link']['url'] : '#';
						$is_external = ! empty( $button['button_link']['is_external'] ) ? ' target="_blank"' : '';
						$nofollow = ! empty( $button['button_link']['nofollow'] ) ? ' rel="nofollow"' : '';

						echo '<a href="' . esc_url( $link ) . '"' . $is_external . $nofollow . '>';
						if ( ! empty( $button['button_icon']['value'] ) ) {
							\Elementor\Icons_Manager::render_icon( $button['button_icon'], [ 'aria-hidden' => 'true' ] );
						}
						echo esc_html( $button['button_text'] );
						echo '</a>';
					}
				}
			echo '</div>';

		echo '</div>';

	}

	
}

<?php

namespace MWEW\Inc\Elementor\Widgets\Area_Map;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Plugin;
use \ElementorPro\Modules\QueryControl\Controls\Template_Query;
use \ElementorPro\Modules\QueryControl\Module as QueryControlModule;
use \ElementorPro\Modules\LoopBuilder\Documents\Loop as LoopDocument;
use \Elementor\Core\Base\Document;
use MWEW\Inc\Services\Map_Repo;
use MWEW\Inc\Database\Listing_Maps_DB;

class Country_Map extends Widget_Base
{

    public function get_name()
    {
        return 'mw_country_map';
    }

    public function get_title()
    {
        return __('MW Country Map', 'listeo');
    }

    public function get_icon()
    {
        return 'eicon-map-pin';
    }

    public function get_categories()
    {
        return ['general'];
    }

    protected function _register_controls()
    {

        // Main Settings
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'listeo'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'label' => __('Tab Title', 'listeo'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Tab Title', 'listeo'),
            ]
        );
        
        $repeater->add_control(
            'map_id',
            [
                'label' => __('Map ID', 'listeo'),
                'type' => Controls_Manager::SELECT,
                'options' => Map_Repo::get_map_id_title(),
                'default' => '',
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => __('Title', 'listeo'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $repeater->add_control(
            'description',
            [
                'label' => __('Description', 'listeo'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => '',
            ]
        );

        $this->add_control(
            'tabs_list',
            [
                'label' => __('Tabs', 'listeo'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->add_control(
            'post_count',
            [
                'label' => __('Number of Posts', 'listeo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );

        $this->add_control(
            'show_dots',
            [
                'label' => __('Show Dots?', 'listeo'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_nav',
            [
                'label' => __('Show Navigation Arrows?', 'listeo'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'items_to_show',
            [
                'label' => __('Items to Show (Desktop)', 'listeo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 6
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay?', 'listeo'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_timeout',
            [
                'label' => __('Autoplay Delay (ms)', 'listeo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 4000,
            ]
        );

        $this->end_controls_section();

        // -------------------
        // Title Style
        // -------------------
        $this->start_controls_section(
            'style_section_title',
            [
                'label' => __('Title Style', 'listeo'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Text Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-map-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Typography', 'listeo'),
                'selector' => '{{WRAPPER}} .mw-bubble-map-title',
            ]
        );

        $this->end_controls_section();

        // -------------------
        // Description Style
        // -------------------
        $this->start_controls_section(
            'style_section_description',
            [
                'label' => __('Description Style', 'listeo'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Text Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-map-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Typography', 'listeo'),
                'selector' => '{{WRAPPER}} .mw-bubble-map-description',
            ]
        );

        $this->end_controls_section();

        // -------------------
        // Button Style
        // -------------------
        $this->start_controls_section(
            'section_tab_buttons_style',
            [
                'label' => __('Tab Buttons Style', 'listeo'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('tabs_button_styles');

        // -----------------------
        // Normal (inactive) tab
        // -----------------------
        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __('Normal', 'listeo'),
            ]
        );

        $this->add_control(
            'tab_button_color',
            [
                'label' => __('Text Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_button_bg_color',
            [
                'label' => __('Background Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // -----------------------
        // Hover state
        // -----------------------
        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'listeo'),
            ]
        );

        $this->add_control(
            'tab_button_hover_color',
            [
                'label' => __('Text Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_button_hover_bg_color',
            [
                'label' => __('Background Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // -----------------------
        // Active state
        // -----------------------
        $this->start_controls_tab(
            'tab_button_active',
            [
                'label' => __('Active', 'listeo'),
            ]
        );

        $this->add_control(
            'tab_button_active_color',
            [
                'label' => __('Text Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button.active' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_button_active_bg_color',
            [
                'label' => __('Background Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button.active' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();


        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .mw-bubble-tab-button',
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'listeo'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 50],
                    '%'  => ['min' => 0, 'max' => 50],
                ],
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label' => __('Padding', 'listeo'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-tab-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'listeo'),
                'selector' => '{{WRAPPER}} .mw-bubble-tab-button',
            ]
        );

        $this->end_controls_section();

        // -------------------
        // Carousel Style
        // -------------------
        $this->start_controls_section(
            'style_section_carousel',
            [
                'label' => __('Carousel Style', 'listeo'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Dots background
        $this->add_control(
            'carousel_dots_bg_color',
            [
                'label' => __('Dots Background Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-carousel-items button.owl-dot' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );

        // Nav icon color
        $this->add_control(
            'carousel_nav_icon_color',
            [
                'label' => __('Nav Icon Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-carousel-items .owl-nav button.owl-prev, {{WRAPPER}} .mw-bubble-carousel-items .owl-nav button.owl-next' => 'color: {{VALUE}};',
                ],
            ]
        );

        // Nav background color
        $this->add_control(
            'carousel_nav_bg_color',
            [
                'label' => __('Nav Background Color', 'listeo'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mw-bubble-carousel-items .owl-nav button.owl-prev, {{WRAPPER}} .mw-bubble-carousel-items .owl-nav button.owl-next' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function get_style_depends() {
	    return ['mw-country-map'];
	}

	public function get_script_depends() {
	    return ['mw-country-map'];
	}


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $post_count = $settings['post_count'];
        $autoplay = $settings['autoplay'] === 'yes' ? 'true' : 'false';
        $show_nav = $settings['show_nav'] === 'yes' ? 'true' : 'false';
        $show_dots = $settings['show_dots'] === 'yes' ? 'true' : 'false';
        $autoplay_timeout = $settings['autoplay_timeout'];
        $items_to_show = $settings['items_to_show'];

        $tabs = $settings['tabs_list'];
        if (empty($tabs)) return;



        echo '<div class="mw-bubble-tent-finder">';



        // Tab Contents
        echo '<div class="mw-bubble-tab-contents">';
        foreach ($tabs as $index => $tab) {
            echo '<div class="mw-bubble-tab-content" data-index="' . $index . '" style="' . ($index === 0 ? '' : 'display:none;') . '">';

            // Region Section
            echo '<div class="mw-bubble-region">';
            // Left Text
            echo '<div class="mw-bubble-left">';
            echo '<h3 class="mw-bubble-map-title">' . esc_html__($tab['title'], 'listeo') . '</h3>';
            echo '<div class="mw-bubble-map-description">' . __(wp_kses_post($tab['description']), 'listeo') . '</div>';
            echo '</div>';

            // Right Map
            echo '<div class="mw-bubble-right">';
            if (!empty($tab['map_id'])) {
                $map = Listing_Maps_DB::get_by_id($tab['map_id']);
                $region = Map_Repo::get_region_by_id($map['region_id']);
                $location_info = Map_Repo::get_listing_info_by_id($tab['map_id']);
                if (!empty($region['image'])) {
                    echo '<figure id="mw-bubble-map-' . $index . '" class="mw-bubble-map" data-listing-info="' . esc_attr(wp_json_encode($location_info)) . '" data-map-data="' . esc_attr(wp_json_encode($map['map_data'])) . '">
                                <img src="' . esc_url($region['image']) . '" alt="' . esc_attr($region['name']) . '" />
                            </figure>';
                    echo '<script>
                        jQuery(document).ready(function($) {
                            setTimeout(function() { 
                                render_map(0);
                            }, 300); // delay first render a little

                            $(".mw-bubble-tab-button").on("click", function() {
                                var index = $(this).data("index");

                                // Update active button
                                $(".mw-bubble-tab-button.active").removeClass("active");
                                $(this).addClass("active");

                                // Show the correct tab content
                                $(".mw-bubble-tab-content").hide();
                                $(".mw-bubble-tab-content[data-index=\'" + index + "\']").show();

                                // Call your map render function
                                render_map(index);
                            });


                            function render_map(index) {
                                var $mapDiv = $("#mw-bubble-map-" + index);
                                var mapData = $mapDiv.data("map-data");
                                var listingData = $mapDiv.data("listing-info");
                                if (typeof mapData === "undefined" || typeof listingData === "undefined") {
                                    console.warn("No map data found for tab " + index);
                                    return;
                                }
                                console.log("Rendering map for tab", index, mapData, listingData);
                                const mapMarkerManager = new MapMarkerManager(mapData, listingData, index);
                            }
                        });
                    </script>';
                }
            }
            // Tab Buttons
            echo '<div class="mw-bubble-tabs">';
            foreach ($tabs as $index => $tab) {
                echo '<button class="mw-bubble-tab-button' . ($index === 0 ? ' active' : '') . '" data-index="' . $index . '">' . esc_html($tab['tab_title']) . '</button>';
            }
            echo '</div>';
            echo '</div>';
            echo '<template id="tooltip-template">
                    <div class="mw-tooltip">
                        <a href="" class="mw-tooltip-url">
                            <div class="mw-tooltip-content">
                                <!-- Price badge -->
                                <div class="mw-tooltip-price">
                                    <span class="price"></span>
                                    <small class="unit"></small>
                                </div>

                                <!-- Image preview (optional) -->
                                <div class="mw-tooltip-image">
                                    <img class="image" src="" alt="Bubble Tent Preview" />
                                </div>

                                <div class="mw-tooltip-content-wrap">
                                    <!-- Name + Location -->
                                    <div class="mw-tooltip-text">
                                        <img src="' . MWEW_PATH_URL . 'assets/images/location.svg" />
                                        <div>
                                            <strong class="name"></strong>
                                            <span class="location"></span>
                                        </div>
                                    </div>

                                    <!-- Date range button style -->
                                    <div class="mw-tooltip-date">
                                        <img src="' . MWEW_PATH_URL . 'assets/images/calendar.svg" />
                                        <span class="date-range"></span>
                                    </div>
                                </div>
                            </div>
                            
                        </a>
                    </div>
                </template>';

            echo '</div>'; // .mw-bubble-region

            // Carousel Section
            echo '<div class="mw-bubble-carousel">';
            if (!empty($tab['template_id'])) {
                $query = new \WP_Query([
                    'post_type' => 'listing',
                    'posts_per_page' => $post_count,
                    'post_status'    => 'publish',
                ]);

                if ($query->have_posts()) {
                    echo '<div class="mw-bubble-carousel-wrapper">';
                    echo '<div class="owl-carousel mw-bubble-carousel-items">';

                    while ($query->have_posts()) {
                        $query->the_post();
                        echo '<div class="item listing-style">';

                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="mw-item-link">';

                                if (has_post_thumbnail()) {
                                    $post_img = get_the_post_thumbnail_url(get_the_ID(), 'large');
                                } else {
                                    $post_img = "https://book-a-bubble.ch/wp-content/uploads/2022/06/Nice-Tense-e1655495112346.png";
                                }

                                if ($post_img) {
                                    echo '<div class="mw-thumb" style="background-image: url(' . esc_url($post_img) . ');">';
                                    
                                    $highlight_features = get_field('highlight_features', get_the_ID());

                                    if ($highlight_features) {
                                        if (is_array($highlight_features)) {
                                            foreach ($highlight_features as $feature_post) {
                                                echo '<span class="mw-feature">' . esc_html(get_the_title($feature_post)) . '</span>';
                                            }
                                        } else {
                                            echo '<span class="mw-feature">' . esc_html(get_the_title($highlight_features)) . '</span>';
                                        }
                                    }
                                    
                                    echo '</div>';
                                }
                                echo '<div class="mw-item-inner">';
                                    echo '<img src="'. MWEW_PATH_URL .'assets/images/location.svg"> <h3 class="mw-title">' . get_the_title() . '</h3>';
                                echo '</div>';

                            echo '</a>';

                        echo '</div>';
                    }


                    echo '</div>'; // .owl-carousel
                    echo '</div>'; // .mw-bubble-carousel-wrapper

                    wp_reset_postdata();

                    // Add JS for both carousel + tabs
                    echo '<script>
                            jQuery(document).ready(function($) {
                                $(".mw-bubble-carousel-items").owlCarousel({
                                    loop: true,
                                    margin: 20,
                                    nav: ' . $show_nav . ',
                                    dots: ' . $show_dots . ',
                                    autoplay: ' . $autoplay . ',
                                    autoplayTimeout: ' . $autoplay_timeout . ',
                                    slideBy: 1,
                                    responsive: {
                                        0: { items: 1 },
                                        768: { items: 2 },
                                        1024: { items: ' . $items_to_show . ' }
                                    }
                                });
                            });
                        </script>';
                }
            }
            echo '</div>'; // .mw-bubble-carousel

            echo '</div>'; // .mw-bubble-tab-content
        }
        echo '</div>'; // .mw-bubble-tab-contents
        echo '</div>'; // .mw-bubble-tent-finder
    }


    public function _content_template()
    {
        // No live preview in the editor
    }
}

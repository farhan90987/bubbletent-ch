<?php

namespace FCSVendor\WPDesk\License;

/**
 * @depreacted 4.0.0 Use LicenseServer\PluginRegistrator directly
 */
final class PluginRegistrator extends \FCSVendor\WPDesk\License\LicenseServer\PluginRegistrator
{
}

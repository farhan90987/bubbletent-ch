<?php

namespace FCSVendor\WPDesk\View\Resolver\Exception;

class CanNotResolve extends \RuntimeException
{
}

<?php

namespace FCSVendor\WPDesk\PluginBuilder\Storage\Exception;

class ClassAlreadyExists extends \RuntimeException
{
}

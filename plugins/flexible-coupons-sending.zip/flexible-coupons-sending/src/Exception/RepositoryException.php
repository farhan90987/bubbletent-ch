<?php

namespace WPDesk\FCS\Exception;

use Exception;

class RepositoryException extends Exception {}

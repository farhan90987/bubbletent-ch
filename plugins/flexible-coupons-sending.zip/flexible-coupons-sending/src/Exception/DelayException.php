<?php

namespace WPDesk\FCS\Exception;

/**
 * Catches unexpected delay data.
 */
class DelayException extends \Exception {}

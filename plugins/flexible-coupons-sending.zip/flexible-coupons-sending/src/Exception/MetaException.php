<?php

namespace WPDesk\FCS\Exception;

/**
 * Catches unexpected meta array.
 */
class MetaException extends \Exception {}
